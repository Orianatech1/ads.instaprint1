<?php $__env->startSection('main-content'); ?>
<body>
<center>
    <div class="error" id="error" style="padding-top: 30px">
            <div class="container">
                <div class="content centered"><img style="width:500px;" src="assets/img/something-lost.png">
                    <h1>Oops, looks like the page is lost.</h1>
                    <p style="font-size:22px;" class="sub-header text-block-narrow">This is not a fault, just an accident that was not intentional.</p>
                </div>
        </div></center>
</body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WebSite Work\InstaPrint\instaprint2\instantprint\resources\views/pages/opps.blade.php ENDPATH**/ ?>