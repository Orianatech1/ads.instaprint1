<?php $__env->startSection('main-content'); ?>
<body>
    <div style="padding-top:50px;">
        <center>
            <img src="assets/img/error-image.png" style="height:60%; width:60%;" />

            <h2 style="margin-top:-15%">Please Contact Customer Support at Live Chat</h2><br>
        </center>
    </div>


</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\WebSite Work\InstaPrint\instaprint2\instantprint\resources\views/pages/install_driver.blade.php ENDPATH**/ ?>